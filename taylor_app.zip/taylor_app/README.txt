==========================================================================
 CONVERGIA - SERIES DE TAYLOR Y MACLAURIN
 Aplicación web interactiva (Python + Flask + SymPy + HTML + CSS + JS)
==========================================================================


--------------------------------------------------------------------------
 1. ¿QUÉ HACE LA APLICACIÓN?
--------------------------------------------------------------------------
Aproxima el valor de cualquier función f(x) con un polinomio de Taylor
(o de Maclaurin) y muestra, término por término, cómo la aproximación se
acerca al valor real.

El usuario ingresa:
  - f(x): la función (ej. sin(x), exp(-x^2), ln(1+x), x^3 + 2*x)
  - x   : el punto donde se quiere aproximar f
  - a   : el punto alrededor del cual se desarrolla la serie
          (vacío o 0 -> Maclaurin; distinto de 0 -> Taylor)
  - N   : cantidad de términos (de 1 a 40)

La aplicación devuelve:
  - Anillos de resumen: precisión %, términos usados y dígitos exactos.
  - Valor real, aproximación final, error absoluto y error relativo.
  - La función y el polinomio resultante escritos en notación matemática.
  - Una tabla con cada iteración (n, f^(n)(a), término, sumatoria,
    error absoluto, error relativo, error relativo %).
  - Tres gráficas: Iteración vs Términos, Iteración vs Sumatoria e
    Iteración vs Errores.
  - Descarga de la tabla en CSV.


--------------------------------------------------------------------------
 2. FUNDAMENTO MATEMÁTICO
--------------------------------------------------------------------------
Serie de Taylor de f alrededor de a:

    f(x) ≈ Σ [ f^(n)(a) / n! * (x - a)^n ]      n = 0, 1, ..., N-1

Serie de Maclaurin (caso particular a = 0):

    f(x) ≈ Σ [ f^(n)(0) / n! * x^n ]            n = 0, 1, ..., N-1

Idea clave: una función suficientemente "suave" se puede imitar con un
polinomio cuyas derivadas en el punto a coinciden con las de la función.
Cada término nuevo corrige un poco más la aproximación.

Errores que se calculan en cada iteración (S_n = suma acumulada):

    Error absoluto  = | valor_real - S_n |
    Error relativo  = | (valor_real - S_n) / valor_real |
    Error relativo % = Error relativo * 100

Convergencia: la serie solo converge si x está dentro de su radio de
convergencia. Ejemplo: 1/(1-x) alrededor de 0 converge para |x| < 1; con
x = 2 la sumatoria se aleja del valor real en lugar de acercarse.


--------------------------------------------------------------------------
 3. INSTALACIÓN Y EJECUCIÓN
--------------------------------------------------------------------------
Requisitos: Python 3.9 o superior (python.org; en Windows marcar
"Add Python to PATH" al instalar) y conexión a internet (la interfaz carga
Chart.js y KaTeX desde un CDN).

--- WINDOWS (CMD) ---
  1) Extraer el zip y abrir el CMD dentro de la carpeta del proyecto
     (en el Explorador: clic en la barra de direcciones, escribir cmd y
     pulsar Enter).
  2) Solo la primera vez:
         py -m venv venv
         venv\Scripts\activate
         pip install -r requirements.txt
  3) Ejecutar:
         venv\Scripts\activate
         python app.py
  4) Abrir en el navegador:  http://127.0.0.1:5000
  5) Para detener el servidor: Ctrl + C en el CMD.

--- LINUX / macOS ---
         python3 -m venv venv
         source venv/bin/activate
         pip install -r requirements.txt
         python app.py

Cada vez que se abre un CMD nuevo hay que volver a activar el entorno
(venv\Scripts\activate). Se sabe que está activo porque aparece (venv) al
inicio de la línea.

Problemas frecuentes:
  - "No module named 'sympy'": el entorno no está activado o falta
    "pip install -r requirements.txt".
  - "'py' no se reconoce": usar "python" en lugar de "py", o reinstalar
    Python marcando Add Python to PATH.
  - El diseño se ve viejo: recargar con Ctrl + F5.
  - Sin gráficas ni fórmulas: revisar la conexión a internet (CDN).


--------------------------------------------------------------------------
 4. ESTRUCTURA DEL PROYECTO
--------------------------------------------------------------------------
taylor_app/
  app.py                  Servidor Flask + cálculo con SymPy
  requirements.txt        Dependencias (Flask, SymPy)
  README.txt              Este documento
  templates/
    index.html            Estructura de la página
  static/
    css/style.css         Diseño visual (tema oscuro, responsive)
    js/app.js             Lógica del navegador, tabla y gráficas

Tecnologías:
  Python ........ lenguaje del servidor y de los cálculos
  Flask ......... servidor web; entrega la página y expone la API
  SymPy ......... matemática simbólica: interpreta f(x) y la deriva
  HTML .......... estructura de la interfaz
  CSS ........... estilo, colores, anillos, diseño adaptable
  JavaScript .... envía datos al servidor, dibuja tabla y gráficas
  Chart.js ...... gráficas (librería externa, por CDN)
  KaTeX ......... fórmulas matemáticas en pantalla (por CDN)


--------------------------------------------------------------------------
 5. CÓMO FUNCIONA (FLUJO COMPLETO)
--------------------------------------------------------------------------
  Navegador (HTML/CSS/JS)                Servidor (Flask + SymPy)
  -----------------------                -------------------------
  1. El usuario llena el formulario
     y pulsa CALCULAR.
  2. app.js envía un JSON a
     POST /api/calcular  ---------------> 3. app.py valida y convierte los
        {f, x, a, n}                         textos en objetos SymPy.
                                          4. Calcula el valor real f(x).
                                          5. Bucle n = 0 ... N-1:
                                             - deriva f n veces (sp.diff)
                                             - evalúa f^(n)(a)
                                             - coeficiente = f^(n)(a)/n!
                                             - término = coef * (x-a)^n
                                             - acumula la sumatoria
                                             - calcula errores
  7. app.js recibe el JSON <------------- 6. Responde un JSON con filas,
     y dibuja anillos, tabla y              valor real, aproximación,
     gráficas.                              LaTeX de f y del polinomio.

Detalle del servidor (app.py):

  parse_function(): convierte el texto en expresión SymPy. Acepta
     multiplicación implícita (2x), ^ como potencia y funciones como sin,
     cos, tan, asin, acos, atan, sinh, cosh, tanh, exp, log/ln, sqrt, abs,
     además de pi y e. SEGURIDAD: solo se permiten nombres de una lista
     blanca y se rechazan caracteres peligrosos, para que nadie pueda
     ejecutar código arbitrario desde el campo de la función.

  parse_number(): igual para x y a (permite pi/2, sqrt(2), etc.). Si a
     está vacío se asume 0.

  calcular(): ruta /api/calcular. Deriva de forma simbólica, de modo que
     f^(n)(a) es EXACTO (no una aproximación numérica). Solo al final los
     valores se convierten a decimales para tabla y gráficas.
     Si ocurre un problema (función no derivable en a, valor complejo,
     N fuera de 1-40, sintaxis inválida) responde un mensaje de error
     claro que se muestra en pantalla.

  to_float(): evalúa con 30 dígitos y convierte a decimal de Python;
     descarta resultados complejos, infinitos o NaN.

Detalle del cliente (app.js):
  - Envía la petición con fetch() y maneja errores.
  - ring(): dibuja los anillos de progreso con SVG:
        Precisión      = 100 - error relativo %
        Términos       = N / 40
        Dígitos exactos = -log10(error relativo), tope 15 (límite de la
                          precisión decimal de un número de 64 bits)
  - drawCharts(): crea las tres gráficas con Chart.js. La gráfica de
    errores usa escala logarítmica porque los errores bajan varios
    órdenes de magnitud; los valores 0 no se dibujan en esa escala.
  - Genera el CSV de la tabla en el propio navegador.

Casos especiales:
  - Si el valor real es 0, el error relativo no está definido y se
    muestra "—".
  - El polinomio simbólico solo se muestra para N <= 12 (si no, ocupa
    demasiado espacio).
  - Funciones como sqrt(x) o ln(x) no se pueden desarrollar en a = 0
    porque no son derivables allí; para ln(x) usar a = 1.


--------------------------------------------------------------------------
 6. CÓMO LEER LOS RESULTADOS
--------------------------------------------------------------------------
  - Aproximación vs valor real: si N es suficiente, coinciden en muchos
    decimales.
  - Gráfica de Términos: cada barra es la contribución de un término.
    Cuando las barras se hacen minúsculas, la serie ya convergió.
    Barras rosas = términos negativos.
  - Gráfica de Sumatoria: la curva azul se acerca a la línea naranja
    punteada (valor real).
  - Gráfica de Errores: una línea que baja rápido indica convergencia
    rápida; si sube o no baja, x está fuera del radio de convergencia o
    a está lejos de x.
  - Dígitos exactos: cuántas cifras decimales de la aproximación son
    correctas.


--------------------------------------------------------------------------
 7. GUÍA PARA LA EXPOSICIÓN (aprox. 10-12 minutos)
--------------------------------------------------------------------------
A) INTRODUCCIÓN (1-2 min)
   - Problema: calculadoras y computadores no "saben" evaluar sin(x) o
     e^x directamente; solo suman y multiplican. Usan polinomios.
   - Solución: las series de Taylor convierten funciones complejas en
     polinomios que sí se pueden calcular.

B) TEORÍA (2-3 min)
   - Mostrar la fórmula de Taylor y la de Maclaurin (a = 0).
   - Explicar con palabras: "el polinomio copia el valor y las derivadas
     de la función en el punto a".
   - Explicar los errores absoluto y relativo, y el radio de convergencia.

C) ARQUITECTURA DEL PROGRAMA (2-3 min)
   - Mostrar el diagrama de la sección 5.
   - Frontend (HTML, CSS, JS): lo que el usuario ve y toca.
   - Backend (Python + Flask): recibe los datos y responde un JSON.
   - SymPy: derivación simbólica exacta; es el "motor matemático".
   - Resaltar la seguridad: lista blanca de funciones permitidas.

D) DEMOSTRACIÓN EN VIVO (4-5 min)  -- guion sugerido
   1. exp(x), x = 1, a vacío, N = 10  (Maclaurin). Mostrar que se acerca
      a e = 2.71828... Señalar anillos, tabla y gráficas.
   2. Subir N a 20 y ver cómo los dígitos exactos aumentan.
   3. sin(x), x = pi/2: ver cómo los términos alternan de signo
      (barras rosas y turquesa).
   4. ln(x) con a = 1, x = 1.5  (Taylor, no Maclaurin: ln(x) no existe
      en 0).
   5. 1/(1-x) con x = 2: la serie DIVERGE; explicar el radio de
      convergencia (|x| < 1). Es el ejemplo más didáctico.
   6. Mostrar el error de sqrt(x) con a = 0 (no derivable en 0).

E) CONCLUSIONES (1 min)
   - Más términos -> menor error (dentro del radio de convergencia).
   - Cuanto más cerca esté x de a, más rápido converge.
   - Python + SymPy permiten automatizar el cálculo simbólico exacto.

Preguntas frecuentes del público y respuestas cortas:
  * ¿Por qué usar SymPy y no derivadas numéricas?
    Porque las derivadas simbólicas son exactas; las numéricas pierden
    precisión rápidamente al derivar varias veces.
  * ¿Por qué la gráfica de errores es logarítmica?
    Porque el error baja de 1 a 1e-15; en escala lineal no se vería.
  * ¿Por qué el máximo de dígitos exactos es 15?
    Es el límite de precisión de los números decimales de 64 bits.
  * ¿Qué pasa si x está lejos de a?
    Se necesitan muchos más términos, o la serie no converge.
  * ¿Es seguro escribir cualquier cosa en el campo de la función?
    Sí: solo se aceptan nombres de una lista blanca de funciones.
  * ¿Cuál es la diferencia entre Taylor y Maclaurin?
    Maclaurin es Taylor con a = 0.
