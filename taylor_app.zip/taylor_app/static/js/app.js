const $ = id => document.getElementById(id);
const EJ = ["sin(x)", "cos(x)", "exp(x)", "exp(-x^2)", "ln(1+x)", "1/(1-x)", "atan(x)", "x^3 + 2*x"];
const C = { teal: "#2dd4a7", blue: "#38bdf8", pink: "#ec4899", orange: "#f5a524", violet: "#8b5cf6" };
let charts = [], last = null;

/* Menú de ejemplos */
const menuMark = () => document.querySelectorAll("#chips button").forEach(b => b.classList.toggle("on", b.dataset.f === $("f").value.trim()));
EJ.forEach(s => {
  const li = document.createElement("li"), b = document.createElement("button");
  b.type = "button"; b.textContent = s; b.dataset.f = s;
  b.onclick = () => { $("f").value = s; menuMark(); $("form").requestSubmit(); };
  li.appendChild(b); $("chips").appendChild(li);
});
$("f").oninput = menuMark; menuMark();
$("n").oninput = () => $("nv").textContent = $("n").value;
const updModo = () => {
  const a = $("a").value.trim();
  $("modo").textContent = (a === "" || +a.replace(",", ".") === 0) ? "a = 0 → Serie de Maclaurin" : "a ≠ 0 → Serie de Taylor";
};
$("a").oninput = updModo; updModo();

/* Utilidades */
const fmt = v => {
  if (v === null || v === undefined || !isFinite(v)) return "—";
  if (v === 0) return "0";
  const m = Math.abs(v);
  return (m < 1e-4 || m >= 1e7) ? v.toExponential(6) : String(+v.toPrecision(10));
};
const tex = (s, el) => { try { katex.render(s, el, { throwOnError: false }); } catch { el.textContent = s; } };

/* Envío */
$("form").onsubmit = async e => {
  e.preventDefault();
  $("err").textContent = ""; $("go").disabled = true; $("go").textContent = "CALCULANDO…";
  try {
    const r = await fetch("/api/calcular", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ f: $("f").value, x: $("x").value, a: $("a").value, n: $("n").value })
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error);
    last = d; render(d);
  } catch (ex) { $("err").textContent = ex.message; }
  finally { $("go").disabled = false; $("go").textContent = "CALCULAR"; }
};

/* Anillos de progreso */
function ring(pct, text, color, title, sub) {
  const r = 46, c = 2 * Math.PI * r, off = c * (1 - Math.max(0, Math.min(100, pct)) / 100);
  return `<div class="ring"><div class="rw"><svg viewBox="0 0 112 112"><circle class="bg" cx="56" cy="56" r="${r}"/>
    <circle class="fg" cx="56" cy="56" r="${r}" stroke="${color}" style="color:${color}" stroke-dasharray="${c}" stroke-dashoffset="${c}" data-off="${off}"/></svg>
    <div class="val">${text}</div></div><b>${title}</b><small>${sub}</small></div>`;
}

/* Render */
function render(d) {
  $("results").hidden = false; $("empty").hidden = true;
  const L = d.rows[d.rows.length - 1];
  const pct = L.rel_err === null ? null : L.rel_err * 100;
  const digits = (L.rel_err === null || L.rel_err === 0) ? 15 : Math.min(15, Math.max(0, -Math.log10(L.rel_err)));
  const prec = pct === null ? 100 : Math.max(0, Math.min(100, 100 - pct));

  $("rings").innerHTML =
    ring(prec, prec.toFixed(prec > 99.99 ? 0 : 2) + "%", C.teal, "Precisión", "100 − error relativo %") +
    ring(d.N / 40 * 100, d.N, C.blue, "Términos", "N de 40 máx.") +
    ring(digits / 15 * 100, digits.toFixed(1), C.pink, "Dígitos exactos", "−log₁₀(error relativo)");
  requestAnimationFrame(() => document.querySelectorAll(".ring .fg").forEach(c => c.style.strokeDashoffset = c.dataset.off));

  $("kind").textContent = d.kind === "Maclaurin" ? "Serie de Maclaurin (a = 0)" : `Serie de Taylor (a = ${fmt(d.a)})`;
  tex("f(x) = " + d.f_latex, $("flat"));
  const st = [["Valor real f(x)", fmt(d.real), "teal"], [`Aproximación (N=${d.N})`, fmt(d.approx), "blue"],
    ["Error absoluto", fmt(L.abs_err), "orange"], ["Error relativo", fmt(L.rel_err) + (pct === null ? "" : ` (${fmt(pct)} %)`), "pink"]];
  $("stats").innerHTML = st.map(([a, b, c]) => `<div class="stat"><small><i class="sq ${c}"></i>${a}</small><b>${b}</b></div>`).join("");
  if (d.poly_latex) tex("P_{" + (d.N - 1) + "}(x) = " + d.poly_latex, $("poly")); else $("poly").textContent = "";

  $("tbl").innerHTML = "<thead><tr><th>n</th><th>f⁽ⁿ⁾(a)</th><th>Término</th><th>Sumatoria</th><th>Error absoluto</th><th>Error relativo</th><th>Error rel. %</th></tr></thead><tbody>" +
    d.rows.map(r => `<tr><td>${r.n}</td><td class="dv" data-t="${encodeURIComponent(r.deriv)}"></td><td>${fmt(r.term)}</td><td>${fmt(r.sum)}</td><td>${fmt(r.abs_err)}</td><td>${fmt(r.rel_err)}</td><td>${r.rel_err === null ? "—" : fmt(r.rel_err * 100)}</td></tr>`).join("") + "</tbody>";
  document.querySelectorAll(".dv").forEach(c => tex(decodeURIComponent(c.dataset.t), c));
  drawCharts(d);
}

/* Gráficas */
function drawCharts(d) {
  charts.forEach(c => c.destroy()); charts = [];
  Chart.defaults.color = "#a29ecb"; Chart.defaults.font.family = "Inter, system-ui, sans-serif";
  const grad = (ctx, a, c1, c2) => { const g = ctx.createLinearGradient(0, a.top, 0, a.bottom); g.addColorStop(0, c1); g.addColorStop(1, c2); return g; };
  const fill = (c1, c2) => c => c.chart.chartArea ? grad(c.chart.ctx, c.chart.chartArea, c1, c2) : c1;
  const lab = d.rows.map(r => r.n), grid = "rgba(255,255,255,.07)";
  const opt = (type = "linear", yt = "") => ({
    responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
    plugins: { legend: { labels: { usePointStyle: true, boxWidth: 8 } }, tooltip: { backgroundColor: "#1d1a3e", padding: 10, cornerRadius: 8 } },
    scales: {
      x: { title: { display: true, text: "Iteración n" }, grid: { display: false }, border: { display: false } },
      y: { type, title: { display: !!yt, text: yt }, grid: { color: grid }, border: { display: false } }
    }
  });
  const pos = v => (v !== null && v > 0) ? v : null;
  const pt = (col) => ({ pointRadius: 5, pointHoverRadius: 7, pointBackgroundColor: "#2a2650", pointBorderColor: col, pointBorderWidth: 2 });

  charts.push(new Chart($("c1"), { type: "bar", data: { labels: lab, datasets: [{ label: "Término n-ésimo", data: d.rows.map(r => r.term), borderRadius: 6, maxBarThickness: 22,
    backgroundColor: c => c.chart.chartArea ? (c.raw >= 0 ? grad(c.chart.ctx, c.chart.chartArea, C.teal, "rgba(56,189,248,.25)") : grad(c.chart.ctx, c.chart.chartArea, "rgba(139,92,246,.25)", C.pink)) : C.teal }] }, options: opt() }));

  charts.push(new Chart($("c2"), { type: "line", data: { labels: lab, datasets: [
    { label: "Sumatoria acumulada", data: d.rows.map(r => r.sum), borderColor: C.blue, borderWidth: 3, tension: .3, fill: "start", backgroundColor: fill("rgba(56,189,248,.5)", "rgba(139,92,246,.04)"), ...pt(C.blue) },
    { label: "Valor real", data: lab.map(() => d.real), borderColor: C.orange, borderDash: [7, 5], borderWidth: 2, pointRadius: 0 }] }, options: opt() }));

  charts.push(new Chart($("c3"), { type: "line", data: { labels: lab, datasets: [
    { label: "Error absoluto", data: d.rows.map(r => pos(r.abs_err)), borderColor: C.pink, borderWidth: 3, tension: .3, fill: "start", backgroundColor: fill("rgba(236,72,153,.4)", "rgba(236,72,153,.02)"), ...pt(C.pink) },
    { label: "Error relativo", data: d.rows.map(r => pos(r.rel_err)), borderColor: C.orange, borderWidth: 3, tension: .3, fill: "start", backgroundColor: fill("rgba(245,165,36,.35)", "rgba(245,165,36,.02)"), ...pt(C.orange) }] },
    options: opt("logarithmic", "Error (escala log)") }));
}

/* CSV */
$("csv").onclick = () => {
  if (!last) return;
  const h = "n,termino,sumatoria,error_absoluto,error_relativo,error_relativo_pct\n";
  const body = last.rows.map(r => [r.n, r.term, r.sum, r.abs_err, r.rel_err ?? "", r.rel_err === null ? "" : r.rel_err * 100].join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([h + body], { type: "text/csv" }));
  a.download = "iteraciones_taylor.csv"; a.click();
};

$("form").requestSubmit();
