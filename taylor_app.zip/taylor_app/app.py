"""Series de Taylor y Maclaurin - Backend Flask + SymPy."""
import math
import re

import sympy as sp
from flask import Flask, jsonify, render_template, request
from sympy.parsing.sympy_parser import (convert_xor, implicit_multiplication_application,
                                        parse_expr, standard_transformations)

app = Flask(__name__)

X = sp.Symbol("x")
TRANSFORMS = standard_transformations + (implicit_multiplication_application, convert_xor)
# Lista blanca: solo estos nombres pueden aparecer en la expresión.
NAMESPACE = {
    "x": X, "pi": sp.pi, "e": sp.E, "E": sp.E,
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "cot": sp.cot, "sec": sp.sec, "csc": sp.csc,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
    "arcsin": sp.asin, "arccos": sp.acos, "arctan": sp.atan,
    "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh,
    "exp": sp.exp, "log": sp.log, "ln": sp.log, "sqrt": sp.sqrt, "abs": sp.Abs,
}
GLOBALS = {"Integer": sp.Integer, "Float": sp.Float, "Rational": sp.Rational, "Symbol": sp.Symbol}
MAX_N, MAX_LEN = 40, 200


class InputError(ValueError):
    pass


def parse_function(text: str) -> sp.Expr:
    text = (text or "").strip()
    if not text:
        raise InputError("Ingresa una función f(x).")
    if len(text) > MAX_LEN or "__" in text or re.search(r"[;\[\]{}'\"\\`]", text):
        raise InputError("La expresión contiene caracteres no permitidos.")
    names = set(re.findall(r"[A-Za-z_]\w*", text)) - set(NAMESPACE)
    if names:
        raise InputError("Nombre(s) no reconocido(s): " + ", ".join(sorted(names)))
    try:
        return parse_expr(text, local_dict=NAMESPACE, global_dict=GLOBALS, transformations=TRANSFORMS)
    except Exception:
        raise InputError("No se pudo interpretar la función. Revisa la sintaxis (usa * ^ ( ) ).")


def parse_number(value, name, default=None) -> sp.Expr:
    s = str(value if value is not None else "").strip().replace(",", ".")
    if s == "":
        if default is None:
            raise InputError(f"Ingresa un valor para {name}.")
        return default
    val = parse_function(s)
    if val.free_symbols:
        raise InputError(f"{name} debe ser un número (puedes usar pi, e, sqrt(2)…).")
    return val


def to_float(v):
    """Convierte a float; devuelve None si es complejo/infinito/NaN."""
    try:
        c = complex(sp.N(v, 30))
    except (TypeError, ValueError):
        return None
    if abs(c.imag) > 1e-12 or not math.isfinite(c.real):
        return None
    return c.real


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/calcular", methods=["POST"])
def calcular():
    d = request.get_json(silent=True) or {}
    try:
        f = parse_function(d.get("f"))
        xv = parse_number(d.get("x"), "x")
        a = parse_number(d.get("a"), "a", default=sp.Integer(0))
        try:
            N = int(d.get("n"))
        except (TypeError, ValueError):
            raise InputError("N debe ser un entero.")
        if not 1 <= N <= MAX_N:
            raise InputError(f"N debe estar entre 1 y {MAX_N}.")

        real = to_float(f.subs(X, xv))
        if real is None:
            raise InputError("f(x) no es un número real finito en el punto x indicado.")

        rows, derivs, poly = [], [], sp.Integer(0)
        deriv, acc = f, 0.0
        for n in range(N):
            dn_a = sp.simplify(deriv.subs(X, a)) if n else f.subs(X, a)
            dn_a = sp.nsimplify(dn_a) if dn_a.is_Float else dn_a
            if dn_a in (sp.zoo, sp.oo, -sp.oo, sp.nan) or to_float(dn_a) is None:
                raise InputError(f"f⁽{n}⁾(a) no está definida o no es real: la función no es derivable en a = {a}.")
            coef = dn_a / sp.factorial(n)
            term_sym = coef * (X - a) ** n
            poly += term_sym
            term = to_float(coef * (xv - a) ** n)
            if term is None:
                raise InputError("Se obtuvo un valor no finito al evaluar un término.")
            acc += term
            ea = abs(real - acc)
            er = ea / abs(real) if real != 0 else None
            rows.append({"n": n, "term": term, "sum": acc, "abs_err": ea, "rel_err": er,
                         "deriv": sp.latex(dn_a), "term_latex": sp.latex(sp.simplify(term_sym))})
            if n < N - 1:
                deriv = sp.diff(deriv, X)

        return jsonify({
            "ok": True, "real": real, "approx": acc,
            "kind": "Maclaurin" if a == 0 else "Taylor",
            "a": to_float(a), "x": to_float(xv), "N": N,
            "f_latex": sp.latex(f), "poly_latex": sp.latex(sp.expand(poly) if a == 0 else poly) if N <= 12 else None,
            "rows": rows,
        })
    except InputError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    except Exception as e:  # noqa: BLE001
        return jsonify({"ok": False, "error": f"No se pudo completar el cálculo: {e}"}), 400


if __name__ == "__main__":
    app.run(debug=True)
